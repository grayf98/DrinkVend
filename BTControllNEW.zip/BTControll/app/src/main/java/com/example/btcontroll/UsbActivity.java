package com.example.btcontroll;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;

public class UsbActivity extends AppCompatActivity {
    private UsbManager usbManager;
    private UsbDevice usbDevice;
    private UsbDeviceConnection usbConnection;

    private Button connectButton;
    private boolean permissionGranted = false;

    private static final String ACTION_USB_PERMISSION = "com.example.btcontroll.USB_PERMISSION";

    Button whiscoke, whisga, whislem, marg, teqoj, teqspri, teqlem, teqsw, vodcran, screw, vodsw, vodspri, vodlem, rumcoke, rumlem, rumga;
    Button splcran, splga, sploj, splsw, splspri, spllem, splcoke;

    Button shotwhis, shotteq, shotvod, shotrum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usb);
        initializeButtons();
        initializeSplashesButtons();
        initializeShotsButtons();


        clicklistners();


        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        registerReceiver(usbReceiver, new IntentFilter(ACTION_USB_PERMISSION));


        // Video
        VideoView videoView = findViewById(R.id.videoView);
        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/raw/" + R.raw.bars);
        videoView.setVideoURI(videoUri);
        videoView.start();
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                videoView.start(); // Restart video
            }
        });

    }
    private void clicklistners() {
        whiscoke.setOnClickListener(v -> {
            sendData("1");
        });
        whisga.setOnClickListener(v -> {
            sendData("8");
        });
        whislem.setOnClickListener(v -> {
            sendData("9");
        });
        marg.setOnClickListener(v -> {
            sendData("2");
        });
        teqoj.setOnClickListener(v -> {
            sendData("10");
        });
        teqspri.setOnClickListener(v -> {
            sendData("11");
        });
        teqlem.setOnClickListener(v -> {
            sendData("12");
        });
        teqsw.setOnClickListener(v -> {
            sendData("13");
        });
        vodcran.setOnClickListener(v -> {
            sendData("3");
        });
        screw.setOnClickListener(v -> {
            sendData("4");
        });
        vodsw.setOnClickListener(v -> {
            sendData("5");
        });
        vodspri.setOnClickListener(v -> {
            sendData("6");
        });
        vodlem.setOnClickListener(v -> {
            sendData("7");
        });
        rumcoke.setOnClickListener(v -> {
            sendData("14");
        });
        rumlem.setOnClickListener(v -> {
            sendData("15");
        });
        rumga.setOnClickListener(v -> {
            sendData("16");
        });
//////////////////splash
        splcran.setOnClickListener(v -> {
            sendData("22");
        });
        splga.setOnClickListener(v -> {
            sendData("23");
        });
        sploj.setOnClickListener(v -> {
            sendData("24");
        });
        splsw.setOnClickListener(v -> {
            sendData("25");
        });
        splspri.setOnClickListener(v -> {
            sendData("26");
        });
        spllem.setOnClickListener(v -> {
            sendData("27");
        });
        splcoke.setOnClickListener(v -> {
            sendData("21");
        });

        ///////////////shots
        shotwhis.setOnClickListener(v -> {
            sendData("17");
        });
        shotteq.setOnClickListener(v -> {
            sendData("18");
        });
        shotvod.setOnClickListener(v -> {
            sendData("19");
        });
        shotrum.setOnClickListener(v -> {
            sendData("20");
        });

    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(usbReceiver);
    }

    private void requestPermission(UsbDevice device) {
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), PendingIntent.FLAG_IMMUTABLE);
        usbManager.requestPermission(device, permissionIntent);
    }

    private void sendData(String data) {

        if (usbDevice != null) {
            if (permissionGranted) {
                // Send data to Arduino here
                if (usbConnection != null) {
                    byte[] bytes = data.getBytes();
                    int sentBytes = usbConnection.bulkTransfer(usbDevice.getInterface(0).getEndpoint(0), bytes, bytes.length, 1000);
                    if (sentBytes < 0) {
                        Log.e("Arduino", "Error sending data");
                    }
                }            } else {
                requestPermission(usbDevice);
            }
        }else {
            Toast.makeText(this, "USB not connected, kindly try to reconnect", Toast.LENGTH_SHORT).show();
        }

    }

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            usbDevice = device;
                            usbConnection = usbManager.openDevice(usbDevice);
                            permissionGranted = true;
                        }
                    } else {
                        Log.d("USB", "Permission denied for device " + device);
                    }
                }
            }
        }
    };


    private void initializeShotsButtons() {
        shotwhis = findViewById(R.id.shotwhis);
        shotteq = findViewById(R.id.shotteq);
        shotvod = findViewById(R.id.shotvod);
        shotrum = findViewById(R.id.shotrum);
    }

    private void initializeSplashesButtons() {
        splcran = findViewById(R.id.splcran);
        splga = findViewById(R.id.splga);
        sploj = findViewById(R.id.sploj);
        splsw = findViewById(R.id.splsw);
        splspri = findViewById(R.id.splspri);
        spllem = findViewById(R.id.spllem);
        splcoke = findViewById(R.id.splcoke);
    }

    private void initializeButtons() {
        whiscoke = findViewById(R.id.whiscoke);
        whisga = findViewById(R.id.whisga);
        whislem = findViewById(R.id.whislem);
        marg = findViewById(R.id.marg);
        teqoj = findViewById(R.id.teqoj);
        teqspri = findViewById(R.id.teqspri);
        teqlem = findViewById(R.id.teqlem);
        teqsw = findViewById(R.id.teqsw);
        vodcran = findViewById(R.id.vodcran);
        screw = findViewById(R.id.screw);
        vodsw = findViewById(R.id.vodsw);
        vodspri = findViewById(R.id.vodspri);
        vodlem = findViewById(R.id.vodlem);
        rumcoke = findViewById(R.id.rumcoke);
        rumlem = findViewById(R.id.rumlem);
        rumga = findViewById(R.id.rumga);

    }
}
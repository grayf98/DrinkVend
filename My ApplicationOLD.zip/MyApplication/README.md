# DrinkVending
This is an Android app UI for a cocktail drink vending machine.

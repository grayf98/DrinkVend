package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import java.util.HashMap;



public class mix extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mix, container, false);

        Button whiscoke = view.findViewById(R.id.whiscoke);
        Button whisga = view.findViewById(R.id.whisga);
        Button whislem = view.findViewById(R.id.whislem);
        Button marg = view.findViewById(R.id.marg);
        Button teqoj = view.findViewById(R.id.teqoj);
        Button teqspri = view.findViewById(R.id.teqspri);
        Button teqlem = view.findViewById(R.id.teqlem);
        Button teqsw = view.findViewById(R.id.teqsw);
        Button vodcran = view.findViewById(R.id.vodcran);
        Button screw = view.findViewById(R.id.screw);
        Button vodsw = view.findViewById(R.id.vodsw);
        Button vodspri = view.findViewById(R.id.vodspri);
        Button vodlem = view.findViewById(R.id.vodlem);
        Button rumcoke = view.findViewById(R.id.rumcoke);
        Button rumlem = view.findViewById(R.id.rumlem);
        Button rumga = view.findViewById(R.id.rumga);





        whiscoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 1 click
                showToast("Button clicked");
            }
        });
        whisga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        whislem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        marg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        teqoj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        teqspri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        teqlem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        teqsw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        vodcran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        screw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        vodsw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        vodspri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        vodlem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        rumcoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        rumlem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        rumga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });

        return view;
    }

    private void showToast(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }
}



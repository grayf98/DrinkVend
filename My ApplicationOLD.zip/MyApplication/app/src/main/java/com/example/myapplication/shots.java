package com.example.myapplication;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class shots extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shots, container, false);

        Button shotwhis = view.findViewById(R.id.shotwhis);
        Button shotteq = view.findViewById(R.id.shotteq);
        Button shotvod = view.findViewById(R.id.shotvod);
        Button shotrum = view.findViewById(R.id.shotrum);
        LayoutInflater layoutInflater = LayoutInflater.from(requireContext());


        shotwhis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click
            }
        });

        shotteq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click
            }
        });

        shotvod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click
            }
        });

        shotrum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click
            }
        });
        return view;
    }
}

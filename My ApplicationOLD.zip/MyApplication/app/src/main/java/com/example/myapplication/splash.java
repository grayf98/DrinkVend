package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import android.widget.Button;

public class splash extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_splash, container, false);

        Button splcran = view.findViewById(R.id.splcran);
        Button splga = view.findViewById(R.id.splga);
        Button sploj = view.findViewById(R.id.sploj);
        Button splsw = view.findViewById(R.id.splsw);
        Button splspri = view.findViewById(R.id.splspri);
        Button spllem = view.findViewById(R.id.spllem);






        splcran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        splga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        sploj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        splsw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        splspri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });

        spllem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button 2 click
            }
        });
        return view;
    }
}
